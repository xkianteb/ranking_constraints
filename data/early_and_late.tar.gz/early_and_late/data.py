import numpy as np
import sys

def main() -> int:
    hor = 400 
    ds = np.zeros((8,hor))
    ds[0] = np.ones(hor)
    ds[1] = np.ones(hor)# * .95
    ds[2] = np.ones(hor)
    ds[3] = np.ones(hor)
    #ds[2] = [-1, .5, -1, .5, -1, .5]#, -1, .5, -1, .5]
    #ds[3] = [.5, -1, .5, -1, .5, -1]
    #ds[4] = [-1, -1, -1, 0., 0., 0.]
    ds[4][:hor//2] = -1
    ds[4][hor//2:] = 0.

    #ds[5] = [.5, .5, .5, 0., 0., 0.]
    ds[5][:hor//2] = .5
    ds[5][hor//2:] = 0.

    #ds[6] = [0., 0., 0., -1, -1, -1]
    ds[6][:hor//2] = 0.
    ds[6][hor//2:] = -1

    #ds[7] = [0., 0., 0., .5, .5, .5]
    ds[7][:hor//2] = 0.
    ds[7][hor//2:] = .5

    np.save('D', np.array(ds).T)
    np.save('R', np.array(ds).T)
    print(f'R')
    print(np.array(ds).T)

#    ds = []
#    sigma = [0.2, 0.2, 1.0] 
#    for d_idx in range(3):
#        print(d_idx)
#        d = []
#        for _ in range(hor):
#            eps =  np.random.normal(0, sigma[d_idx]) 
#            d.append(mu[d_idx] + eps)
#        ds.append(d)
#    np.save('D', np.array(ds).T)
#    print(f'D')
#    print(np.array(ds).T)
    return 0

if __name__ == '__main__':
    sys.exit(main())  # next section explains the use of sys.exit
